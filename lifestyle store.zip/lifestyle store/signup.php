<?php
include 'common.php';
?>


<!DOCTYPE html>
<html>
<head>
	<title>Lifestyle Store</title><!--this is the title for my web page-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" ><!--this is link to bootstrap css file-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script><!--this is link to jquery-->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css"><!--this is link to style.css-->
	<meta name="viewpoint" content="width=device-width" initial-sale="1"><!--meta tag used to srink the page as to the divice screen-->
</head>

<body style="background-color:hsla(120, 100%, 25%, 0.3)">


<?php
require 'header.php';
?>

<div class="container margin">
<div class="panel-group margin">
<div class="panel panel-primary">
	<div class="panel-header bg"><a href="index.php"><img src="images/lifestylelogo.png" alt="logo" class="size"></a>
								<strong>Sign Up</strong><span class="glyphicons glyphicons-keys"></span></div>
	<div class="panel-body">
					<div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
					<form method="post" action="user_reistration_script.php">
            <div class="form-group">
                <input class="form-control" placeholder="Name" name="name"  required = "true">
            </div>
            <div class="form-group">
				<input type="email" class="form-control"  placeholder="Email"  name="email" required = "true">
            </div>
            <div class="form-group">
				<input type="password" class="form-control" placeholder="Password" name="password" required = "true">
            </div>
            <div class="form-group">
				<input type="text" class="form-control"  placeholder="Contact" name="contact" required = "true">
            </div>
            <div class="form-group">
                <input class="form-control"  placeholder="City" name="city" required = "true">
            </div>
            <div class="form-group">
                <input class="form-control"  placeholder="Address" name="address" required = "true">
            </div>
                <a href="product.php"><button type="submit" name="submit" class="btn btn-primary">Submit</button></a>
            </form>
					</div>
	</div>
	<div class="panel-footer">
					Allready member to Lifestyle.com? <a href="login.php">click here</a>for log-in
	</div>
</div>
</div>
</div>



<?php
require 'footer.php';
?>
</body>
</html>