<?php
include 'common.php';
?>


<!DOCTYPE html>
<html>
<head>
	<title>Lifestyle Store</title><!--this is the title for my web page-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" ><!--this is link to bootstrap css file-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script><!--this is link to jquery-->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css"><!--this is link to style.css-->
	<meta name="viewpoint" content="width=device-width" initial-sale="1"><!--meta tag used to srink the page as to the divice screen-->
</head>

<body style="background-color:hsla(120, 100%, 25%, 0.3)">

<?php 
require 'header.php';
?>


<div class="container center margin">
<div class="container panel-header center bg">
<h1>Welcome to our Lifestyle Store!!</h1>
we have best camera, shirts and watches for you. No need to hunt around, we have all in one place.
</div>
</div>



<div class="container margin">
	<h1>Camera</h1>
	<div class="row">
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/camera1.jpg" alt="responsive-image" class="img-thumbnail"></a>
			<div class="caption center">
			<h3>LUMIX 820R xxlR</h3>price 800$
			</div>
			 <div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>			 
		</div>
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/camera2.jpg" alt="responsive-image" class="img-thumbnail"></a>
			<div class="caption center">
			<h3>CANON SLR 4500 xtra</h3>price 100$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/camera3.jpg" alt="responsive-image" class="img-thumbnail"></a>
			<div class="caption center">
			<h3>CANON SLR 400R xl</h3>price 90$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
			<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/camera4.jpg" alt="responsive-image" class="img-thumbnail"></a>
			<div class="caption center">
			<h3>NIKON</h3>price 50$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
	</div>
</div>

<div class="container margin">
	<div class="row">
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/camera5.jpg" alt="responsive-image" class="img-thumbnail"></a>
			<div class="caption center">
			<h3>CANON xxlR</h3>price 90$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/camera6.jpg" class="img-thumbnail" alt="responsive-image"></a>
			<div class="caption center">
			<h3>CAMRECORDER dxlr</h3> price 180$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/camera7.jpeg" alt="responsive-image" class="img-thumbnail"></a>
			<div class="caption center">
			<h3>NICON</h3>price 50$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
			<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/camera8.jpg" alt="responsive-image" class="img-thumbnail"></a>
			<div class="caption center">
			<h3>SONY aqua</h3>price 50$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
	</div>
</div>

<div class="container margin">
	<h1>Shirts</h1>
	<div class="row">
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/shirt1.jpg" alt="responsive-image"class="img-thumbnail"></a>
			<div class="caption center">
			<h3>Lifestyle Shirt</h3>price 20$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/shirt2.jpg" alt="responsive-image"class="img-thumbnail"></a>
			<div class="caption center">
			<h3>Lifestyle Shirt</h3>price 20$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/shirt3.jpg" alt="responsive-image"class="img-thumbnail"></a>
			<div class="caption center">
			<h3>Lifestyle Shirt</h3>price 20$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/shirt4.jpg" alt="responsive-image"class="img-thumbnail"></a>
			<div class="caption center">
			<h3>Lifestyle Shirt</h3>price 20$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
	</div>

</div>

<div class="container margin">
	<div class="row">
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/shirt5.jpg" alt="responsive-image"class="img-thumbnail"></a>
			<div class="caption center">
			<h3>Lifestyle Shirt</h3>price 20$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/shirt6.jpg" alt="responsive-image"class="img-thumbnail"></a>
			<div class="caption center">
			<h3>Lifestyle Shirt</h3>price 20$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/shirt7.jpg" alt="responsive-image"class="img-thumbnail"></a>
			<div class="caption center">
			<h3>Lifestyle Shirt</h3>price 20$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/shirt8.jpg" alt="responsive-image"class="img-thumbnail"></a>
			<div class="caption center">
			<h3>Lifestyle Shirt</h3>price 20$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
	</div>
</div>

<div class="container margin">
<h1>Watches</h1>
	<div class="row">
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/watch1.jpg" alt="responsive-image"class="img-thumbnail"></a>
			<div class="caption center">
			<h3>Lifestyle Watch</h3>price 50$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/watch2.jpg" alt="responsive-image"class="img-thumbnail"></a>
			<div class="caption center">
			<h3>Lifestyle Watch</h3>price 50$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/watch3.jpg" alt="responsive-image"class="img-thumbnail"></a>
			<div class="caption center">
			<h3>Lifestyle Watch</h3>price 50$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/watch4.jpg" alt="responsive-image"class="img-thumbnail"></a>
			<div class="caption center">
			<h3>Lifestyle Watch</h3>price 50$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
	</div>

<div class="container margin">
	<div class="row">
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/watch5.jpg" alt="responsive-image"class="img-thumbnail"></a>
			<div class="caption center">
			<h3>Lifestyle Watch</h3>price 50$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/watch6.jpg" alt="responsive-image"></a>
			<div class="caption center">
			<h3>Lifestyle Watch</h3>price 50$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/watch7.jpg" alt="responsive-image"class="img-thumbnail"></a>
			<div class="caption center">
			<h3>Lifestyle Watch</h3>price 50$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
		<div class="col-sm-3 thumbnail">
			<a href="#" class="thumbnail"><img src="images/watch8.jpg" alt="responsive-image"class="img-thumbnail"></a>
			<div class="caption center">
			<h3>Lifestyle Watch</h3>price 50$
			</div>
			<div> <button type="submit" name="cart" class="btn btn-primary btn-block">Add to cart</button></form>
			</div>
		</div>
	</div>

</div>


<?php
require 'footer.php';
?>
</body>
</html>