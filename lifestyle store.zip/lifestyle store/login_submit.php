
<?php 
require 'header.php';
?>

<?php
require 'common.php';
$email = mysqli_real_escape_string($con, $_POST['email']);
$password = mysqli_real_escape_string($con, $_POST['password']);
$user_submit_query = "SELECT id FROM users WHERE email = '$email' and password = '$password'";
$user_registration_submit=mysqli_query($con, $user_submit_query) or die(mysqli_error($con));

if(mysqli_num_rows($user_registration_submit) == 0)
{
	echo "<h1>no record found</h1>";
}
else
{
	$result = mysqli_fetch_assoc($user_registration_submit); // You can use mysqli_fetch_row, mysqli_fetch_array, mysqli_fetch_object as well
	$_SESSION["id"] = $result["id"];
	//redirect to dashboard using header("location: page_name.php")
	$_SESSION['email'] = $email;
$_SESSION['id'] = mysqli_insert_id($con);
	if(!isset($_SESSION["username"])){
header("Location: product.php");
exit(); }}
?>