<?php
include 'common.php';
?>


<!DOCTYPE html>
<html>
<head>
	<title>Lifestyle Store</title><!--this is the title for my web page-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" ><!--this is link to bootstrap css file-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script><!--this is link to jquery-->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css"><!--this is link to style.css-->
	<meta name="viewpoint" content="width=device-width" initial-sale="1"><!--meta tag used to srink the page as to the divice screen-->
</head>

<body style="background-color:hsla(120, 100%, 25%, 0.3)">

<?php 
require 'header.php';
?>


<div class="container margin">
<div class="panel-group margin">
<div class="panel panel-primary">
	<div class="panel-header bg"><a href="index.php"><img src="images/lifestylelogo.png" alt="logo" class="size"></a>
								<strong>Change Password</strong><span class="glyphicons glyphicons-keys"></span></div>
	<div class="panel-body">
					<div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3">
					<form method="post" action="update_name.php">
						<div class="form-group">
							<input type="password" class="form-control" placeholder="Old Password" name="password" required = "true">
						</div>
						<div class="form-group">
							<input type="password" class="form-control" placeholder="New Password" name="password" required = "true">
						</div>
						<div class="form-group">
							<input type="password" class="form-control" placeholder="Re-type New Password" name="password" required = "true">
						</div>
						    <button type="submit" name="submit" class="btn btn-primary">change</button>
					</form>
					</div>
	</div>
	<div class="panel-footer">
					New to Lifestyle.com? <a href="signup.php">Become a member</a>
	</div>
</div>
</div>
</div>


<?php
require 'footer.php';
?>
</body>
</html>