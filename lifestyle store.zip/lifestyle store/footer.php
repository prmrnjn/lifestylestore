<div class="container-fluid margin">
<div class = "row">
	<div class="col-sm-4 col-md-4 col-lg-4 center">
	<h1>Information</h1>
	<ul type="none">
		<li><a href="aboutus.php">About Us</a></li>
		<li><a href="contact.php">Contact Us</a></li>
	</ul>
	</div>
	
	<div class="col-sm-4 col-md-4 col-lg-4 center">
	<h1>My Account</a></h1>
	<ul type="none">
		<li><a href="signup.php">Sign Up</a></li>
		<li><a href="login.php">Sign In</a></li>                
				<?php                 
				if (isset($_SESSION['email'])) {                     
				?>      
		<li><a href="logout_script.php">Sign Out</a></li>
		<?php 
                } else                   
				?>   
	</ul>
	</div>
	
	<div class="col-sm-4 col-md-4 col-lg-4 center">
	<h1>Contact</h1>
	<ul type="none">
		<li><a href="index.php">Lifestyle</a></li>
		<li><a href="#">+91 7991160033</a></li>
	</ul>
	</div>
</div>

	<div class="footer">
      Copyright ©Lifestyle Store. All Right Reserved | contact Us: +91 7991160033 | <a href="">Privacy Policy</a> | <a href="">Terms of Service</a>
	</div>
</div>