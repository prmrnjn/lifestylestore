-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Oct 31, 2017 at 09:34 AM
-- Server version: 5.7.19
-- PHP Version: 5.6.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `store`
--

-- --------------------------------------------------------

--
-- Table structure for table `contat`
--

DROP TABLE IF EXISTS `contat`;
CREATE TABLE IF NOT EXISTS `contat` (
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `contact` varchar(10) NOT NULL,
  `city` varchar(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  `feedback` varchar(500) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contat`
--

INSERT INTO `contat` (`name`, `email`, `contact`, `city`, `address`, `feedback`) VALUES
('prem ranjan', 'prem1@gmail.com', '1234', 'patna', 'Bhuth nath road', 'good interface'),
('', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
CREATE TABLE IF NOT EXISTS `items` (
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `id` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`name`, `price`, `id`) VALUES
('LUMIX 820R xxlR', 800, 1),
('CANON SLR 4500 xtra', 100, 2),
('CANON SLR 400R xl', 90, 3),
('nicon', 50, 4),
('CANON xxlR', 90, 5),
('CAMRECORDER dxlr', 180, 6),
('SONY aqua', 50, 7),
('Lifestyle Shirt', 20, 8),
('Lifestyle Watch', 50, 9);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `email` varchar(20) DEFAULT NULL,
  `contact` int(10) DEFAULT NULL,
  `password` varchar(9) NOT NULL,
  `city` varchar(10) NOT NULL,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `contact`, `password`, `city`, `address`) VALUES
(1, 'prem', 'prem@gmail.com', 55545, '123', 'patna', 'adarsh colony'),
(4, 'prem', 'prem@gmail.com', 55545, '123', 'patna', 'adarsh colony'),
(2, 'prem ranjan', 'prem1@gmail.com', 875454545, '1234', 'patna', 'adarsh colony 1'),
(3, 'pm mishra', 'prem3@gmail.com', 875454545, '12345', 'patna', 'adarsh colony 2'),
(5, 'nehashikha', 'neha1234@gmail.com', 456328971, '456', 'patna', 'agamkuha patna'),
(6, 'rana sashi ranjan', 'rana@gmail.com', 12364, 'rana123', 'patna', 'bn road'),
(7, 'vishal', 'vishu@rediffmail.com', 456, 'vishal123', 'araha', 'gorakha nagar'),
(8, 'vishal', '', 456, '235', 'araha', 'gorakha nagar araha'),
(9, 'vishal kapoor', '', 456, 'vishal123', 'patna', 'gorakha nagar araha'),
(10, 'raj', 'raj@gmail.com', 1234, 'raj@123', 'patna', 'ramnagar patna'),
(11, 'mani', 'mani@sify.com', 456, 'mani', 'patna', 'progress colony'),
(12, 'mani ranjan', 'mani120@sify.com', 456, 'mani', 'patna', 'progress colony'),
(13, 'ravi ranjan', 'ravi120@sify.com', 456, 'ravi', 'patna', 'progress colony'),
(14, 'prem chopra', 'chopra@sify.com', 258896, '258', 'patna', 'rajkamal'),
(15, 'bitu', 'bitu@gmail.com', 1234, 'bitu@1234', 'patna', 'prabha kunj');

-- --------------------------------------------------------

--
-- Table structure for table `users_item`
--

DROP TABLE IF EXISTS `users_item`;
CREATE TABLE IF NOT EXISTS `users_item` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `status` enum('addtocart','confirmed') NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
