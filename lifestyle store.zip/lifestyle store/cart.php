<?php
include 'common.php';
?>


<!DOCTYPE html>
<html>
<head>
	<title>Lifestyle Store</title><!--this is the title for my web page-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" ><!--this is link to bootstrap css file-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script><!--this is link to jquery-->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css"><!--this is link to style.css-->
	<meta name="viewpoint" content="width=device-width" initial-sale="1"><!--meta tag used to srink the page as to the divice screen-->
</head>

<body style="background-color:hsla(120, 100%, 25%, 0.3)">

<?php 
require 'header.php';
?>


<div class="container margin">

	<h1>Shopping Cart</h1><hr>
	<table class="table table-striped table-hover table-bordered margin">
        <tbody>
            <tr>
                <th>Item Number</th>
                <th>Item</th>
                <th>Unit Price</th>
                <th></th>
            </tr>
            <tr>
                <td>1</td>
                <td>camera <a href="#">X</a></td>
                <td>$250.00</td>
                <td></td>
            </tr>
            <tr>
                <th colspan="3"><span class="pull-right">Sub Total</span></th>
                <th>$250.00</th>
            </tr>
            <tr>
                <th colspan="3"><span class="pull-right">VAT 20%</span></th>
                <th>$50.00</th>
            </tr>
            <tr>
                <th colspan="3"><span class="pull-right">Total</span></th>
                <th>$300.00</th>
            </tr>
            <tr>
                <td><a href="#" class="btn btn-primary">Continue Shopping</a></td>
                <td colspan="3"><a href="#" class="pull-right btn btn-success">Checkout</a></td>
            </tr>
        </tbody>
    </table>          
      
</div>

<?php
require 'footer.php';
?>
</body>
</html>