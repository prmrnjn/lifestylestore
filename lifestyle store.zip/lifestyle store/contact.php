<html>
<head>
<title> Contact Us</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" ><!--this is link to bootstrap css file-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script><!--this is link to jquery-->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css"><!--this is link to style.css-->
	<meta name="viewpoint" content="width=device-width" initial-sale="1">

</head>
<body style="background-color:hsla(120, 100%, 25%, 0.3)">
<?php
include "header.php";
?>
<div class="container-fluid margin">
<div class="row">
    <div class="col-sm-3 col-md-3 col-lg-3">
	<div class="col-lg-4 col-lg-offset-4 col-md-6 col-md-offset-3 margin">
					<form method="post" action="contact_submit.php">
            <div class="form-group">
                <input class="form-control" placeholder="Name" name="name" size="50" required = "true">
            </div>
            <div class="form-group">
				<input type="email" class="form-control"  placeholder="Email"  name="email" size="50" required = "true">
            </div>
            
            <div class="form-group">
				<input type="text" class="form-control"  placeholder="Contact" name="contact" size="50" required = "true">
            </div>
            <div class="form-group">
                <input type ="text" class="form-control"  placeholder="City" name="city" size="50"required = "true">
            </div>
            <div class="form-group">
                <input type="text" class="form-control"  placeholder="Address" name="address" size="50" required = "true">
            </div>
			<div class="form-group">
				 <input type="text" class="form-control"  placeholder="your feedback" name="feedback" size="50" required = "true">
            </div>
				<div class="form-group">
            <input type="submit" value="Submit">
			<input type="reset">
			</div>
            </form>
					</div>
	</div>
	 <div class="col-sm-9 col-md-9 col-lg-9">
	 <div class="margin">
	 <img src="images/contact.jpg" alt="images/contact.jpg"/></br>
	 <p >
	 lifestyle store || xyz cooperation.</br>
	 azad nagar, anandpur patna-800026</br>
	 Patna (Bihar)</br>
	 mob-+91 7991160033</br>
	 email-prmrnjn28@gmail.com</br>
	 web- http://www.premblogweb.com/</br></p>
	 
	 </div>
	</div>
</div>
</div

<?php
include "footer.php";
?>
</body></html>