<!DOCTYPE html>
<html>
<head><title>new user</title>
<title>Lifestyle Store</title><!--this is the title for my web page-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" ><!--this is link to bootstrap css file-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script><!--this is link to jquery-->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css"><!--this is link to style.css-->
	<meta name="viewpoint" content="width=device-width" initial-sale="1"><!--meta tag used to srink the page as to the divice screen-->
</head>
<body>
<?php 
require 'header.php';
?>


<div class="margin">
<?php
require 'common.php';
$name = mysqli_real_escape_string($con, $_POST['name']);
$email = mysqli_real_escape_string($con, $_POST['email']);
$password = mysqli_real_escape_string($con, $_POST['password']);
$contact = mysqli_real_escape_string($con, $_POST['contact']);
$city = mysqli_real_escape_string($con, $_POST['city']);
$address = mysqli_real_escape_string($con, $_POST['address']);
$user_registration_query = "insert into users(name,email,password,contact,city,address) 
values ('$name' , '$email' , '$password' , '$contact' , '$city' , '$address')";
$user_registration_submit=mysqli_query($con, $user_registration_query) or die(mysqli_error($con));

echo "<h6>User successfully inserted</h6>";
$_SESSION['email'] = $email;
$_SESSION['id'] = mysqli_insert_id($con);
?>
</div>


<?php
require 'footer.php';
?>
</body>
</html>