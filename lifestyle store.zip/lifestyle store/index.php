
<?php

if (isset($_SESSION['email'])) {
  echo "<h1>Hello </h1>".$_SESSION[‘email’];
} else {
  echo "<h1>Hello Guest</h1>";
}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Lifestyle Store</title><!--this is the title for my web page-->
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" ><!--this is link to bootstrap css file-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script><!--this is link to jquery-->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css"><!--this is link to style.css-->
	<meta name="viewpoint" content="width=device-width" initial-sale="1"><!--meta tag used to srink the page as to the divice screen-->
</head>

<body style="background-color:hsla(120, 100%, 25%, 0.3)">

<?php 
require 'header.php';
?>

<div class="container-fluid">
<div id="banner_image">
	<center><div id="banner-content">
					<h1>We Sell Lifestyle</h1>
					<p>Flat 40% OFF on prenium Brands</p>
					<a href="product.php"><button type="button" class="btn btn-danger btn lg-active">ShopNow</button></a></div>
	</center>
</div>
</div>


<div class="container margin">
	<h1>Lifestyle Products</h1>
	<div class="row">
		<div class="col-sm-4">
			<a href="product.php" class="thumbnail"><img src="images/watch.jpg" alt="responsive-image"></a>
			<div class="caption center">
			<h3>WATCHES</h3>choose among the best available in the world.
			</div>
		</div>
		<div class="col-sm-4">
			<a href="product.php" class="thumbnail"><img src="images/shirt.jpg" alt="responsive-image"></a>
			<div class="caption center">
			<h3>SHIRT</h3>choose among the best available in the world.
			</div>
		</div>
		<div class="col-sm-4">
			<a href="product.php" class="thumbnail"><img src="images/camera2.jpg" alt="responsive-image"></a>
			<div class="caption center">
			<h3>CAMERA</h3>choose among the best available in the world.
			</div>
		</div>
	</div>
</div>

<?php
include 'footer.php';
?>
</body>
</html>