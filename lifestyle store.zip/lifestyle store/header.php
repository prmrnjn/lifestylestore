
<div class="navbar navbar-inverse navbar-fixed-top">    
	<div class="container-fluid">         
		<div class="navbar-header">            
		<button type="button" class="navbar-toggle" data-toggle="collapse" datatarget="#myNavbar">                 
			<span class="icon-bar"></span>                 
			<span class="icon-bar"></span>                 
			<span class="icon-bar"></span>                                     
		</button>            
			<a class="navbar-brand" href="index.php"><img src="images/lifestylelogo.png" alt="logo" class="size"></a>         
		</div>  
		
		<div>
		<ul class="nav navbar-nav navbar-right"> 
			<li><a href="aboutus.php"> <span class = "glyphicon glyphicon-hourglass">About Us</a></li>
			<li><a href="contact.php"> <span class = "glyphicon glyphicon-earphone"></span>Contact Us</a></li>
			<li><a href="#"><?php

if (isset($_SESSION['email'])) {
  echo "Hello".$_SESSION[‘email’];
} else {
  echo "Hello Guest!!";
}
?></a></li>
		</ul>
		</div>
      
		<div class="collapse navbar-collapse" id="myNavbar">             
			<ul class="nav navbar-nav navbar-right">                
				<?php                 
				if (isset($_SESSION['email'])) {                     
				?>                     		
				<li><a href = "cart.php"><span class="glyphicon glyphicon-shopping-cart"></span> Cart </a></li>
				<li><a href = "settings.php"><span class = "glyphicon glyphicon-wrench"></span> Settings</a></li>
				<li><a href = "logout_script.php"><span class = "glyphicon glyphicon-eye-close"></span> Logout</a></li>                  
				<?php 
                } else {                    
				?>                     
				<li><a href="signup.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
				<li><a href="login.php"><span class="glyphicon glyphicon-log-in"></span> Login</a></li> 
				<?php                     
				}                     
				?>  
				
			</ul>         
		</div>    
	</div> 
</div>