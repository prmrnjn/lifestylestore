<html>
<head>
<title> About Us</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" ><!--this is link to bootstrap css file-->
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script><!--this is link to jquery-->
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<link rel="stylesheet" type="text/css" href="style.css"><!--this is link to style.css-->
	<meta name="viewpoint" content="width=device-width" initial-sale="1">

</head>
<body style="background-color:hsla(120, 100%, 25%, 0.3)">
<?php
include "header.php";
?>


<div class="container-fluid margin">
<div class="row">
    <div class="col-sm-4 col-md-4 col-lg-4">
	<h1>Who are we</h1>
	<img src="images/aboutus.jpg" alt="no image found"/>
      <p>There's a dedicated team of people working at the Krishna.com office and warehouse to share Lord Krishna’s teachings
	  with more than 4000 visitors a day (1.46 million per year) from 228 countries, territories and islands. Fall is when Krishna.com’s annual bills are due, property tax 
	  ($5200), insurance ($3150), email newsletter service ($2145), and a new roof after the hurricane ($6000), 
	  totaling $16,495. We need your help to keep Krishna.com alive and vibrant. </p>
	  <p>The statement in the Upanishads is aham brahmasmi, "I am Brahman;" that is to say,
	  I am spirit. The corollary is that "I am not matter," and the meaning of that is, "I am not this body."</p>
	  <p>So, according to the Vedas, the real self is not the body. By "body," they mean the body and what we call the mind. According to the Vedas, we have a gross body made 
	  of earth and water and air and so on, and we have a subtle body, which we experience as mind – thinking, feeling and willing – this is the subtle body.</p>
	  <p>But beyond this is the soul. I am not the gross body nor am I my mind. And then people will say, "well, what's left?" and what's left, what is the soul, is consciousness. Consciousness is the symptom of the presence of soul. 
	  So we know of the existence of the self because of consciousness.
	  Consciousness does not arise out of material interactions.</p>
	  <p>Take as our authorities material scientists, who want to claim that all of reality can be explained by 
	  simply expressing it in terms of numbers. This is "hard science." Ultimately, it's mathematics. And that all there 
	  is in the world are structures of matter, and these structures of matter can be completely explained in terms of numbers.

And then they tell a story – this is the "scientific myth" – that in the beginning there were very, very simple elementary 
structures of matter. How they got there, they don't talk about, but that's what they say. And then, over the course of time, 
for some inexplicable reason, these structures of matter become more complex.

Now, all of these structures of matter can be fully expressed in terms of numbers. You can exhaust the content of reality by a string of ones and zeros.
 They get more complicated, and then they present this picture of evolution – at first, there are subatomic particles, and then these subatomic particles — gluons, muons, quarks, 
 
charm quarks and everything — they come into contact with each other, and they form more complex entities, and then eventually you have atoms.
	  </p>
    </div>
    <div class="col-sm-4 col-md-4 col-lg-4" >
     <h1>Our History</h1>  
     <img src="images/lifestylelogo.png" alt="no image found" style="width:100px; hight:60px;"/>	 
	 <p>lifestyle is an electronic commerce company headquartered in Bengaluru, India. It was founded in October 2007 by 
	 Sachin Bansal and Binny Bansal (no relation).[4] lifestyle has
	 launched its own product range under the name "DigiFlip" with products including tablets, 
	 USBs, and laptop bags.[5][6][7] As of April 2017, the company was valued at $11.6 billion</p>
	 
	 <p>lifestyle was founded on 2007 by Sachin Bansal and Binny Bansal , both alumni of the Indian Institute of Technology Delhi.
	 They worked for Amazon.com, and left to create their new company incorporated in October 2007 as lifestyle Online Services Pvt. Ltd.[9] 
	 The first product they sold was the book Leaving Microsoft To Change The World to a customer from Hyderabad.[10][11][12] lifestyle now employs more than 33,000 people.[13]
In October and November 2011, lifestyle acquired the websites Mime360.com[14] and Chakpak.com.[15] Later, in February 2012, 
the company revealed its new Flyte Digital Music Store.[16] Flyte, a legal music download service in the vein of iTunes and Amazon.com, 
offered DRM-free MP3 downloads. But it was shut down on 17 June 2013 as paid song downloads did not get popular in India due to the advent of free music 
streaming sites.[17][18][19]

After its 2014 Big Billion Sale, lifestyle carried out a second Big Billion Sale.[20] Where it is reported that they saw a business turnover of
 $300 million in gross merchandise volume.[21]

In 2015, lifestyle bought a minority stake in navigation and route optimization startup MapmyIndia to help improve its delivery using Map my India assets.[citation needed]

</p>
    </div>
	 <div class="col-sm-4 col-md-4 col-lg-4">
	 <h1>Opportunities</h1>
      <p>Sed ut perspiciatis...</p>
    </div>
  </div>
</div>


<?php
include "footer.php";
?>
</body></html>