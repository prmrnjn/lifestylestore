<?php 
require 'header.php';
?>

<?php

$con = mysqli_connect("localhost", "root", "", "ecommerce") or die(mysqli_error($con));
session_start();
$new_password = $_GET['password'];
$user_id = $_SESSION['id'];
$update_name_query = "UPDATE users SET password = '$new_password' WHERE id = '$user_id'";
$update_name_result = mysqli_query($con, $update_name_query) or die(mysqli_error($con));
echo "password updated";
?>